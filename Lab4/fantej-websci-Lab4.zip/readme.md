It sure seems AngularJS is a very robust framework, but it will take getting used to because I am so use to using good old JQuery to manipulate webpages.

Requirements:

API: Openweathermap API (10 day weather forecast) 
Media Queries: Used to modify row border colors based on device size (extra small, small, medium, and large devices)/Used to change background color for smaller devices
Angular: Tabbed Button Interface/Used to make the GET request/Used to add the image to the page